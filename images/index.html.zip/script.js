// Firebase Configuration - ТУК СЛАГАШ ТВОИТЕ КЛЮЧОВЕ ОТ FIREBASE КОНЗОЛАТА
const firebaseConfig = {

  apiKey: "AIzaSyBXQLq0zmjUEXzKDHUzyASanD3AYzvNyoE",

  authDomain: "local-harvest-bg.firebaseapp.com",

  projectId: "local-harvest-bg",

  storageBucket: "local-harvest-bg.firebasestorage.app",

  messagingSenderId: "963913514176",

  appId: "1:963913514176:web:632c12e367eae8be874125",

  measurementId: "G-KXFY8HZGVK"

};

    // Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();

auth.setPersistence(firebase.auth.Auth.Persistence.SESSION);

let currentUser = null;
let currentFarmerData = null;

// Auth State Listener (проверява дали си логнат)
auth.onAuthStateChanged((user) => {
    if (user) {
        currentUser = user;
        loadFarmerData(user.uid);

        // 🔥 ADD THIS LINE
        loadAllProducts();

    } else {
        currentUser = null;
        currentFarmerData = null;
        updateUIForGuest();

        // 🔥 ALSO ADD HERE (so UI updates on logout)
        loadAllProducts();
    }
});

// Load Farmer Data
async function loadFarmerData(uid) {
    try {
        const doc = await db.collection('farmers').doc(uid).get();
        if (doc.exists) {
            currentFarmerData = doc.data();
            updateUIForLoggedInFarmer();
            loadMyProducts(uid);


            // 🔥 ADD THIS LINE HERE
            loadAllProducts();
        }
    } catch (error) {
        console.error("Error loading farmer:", error);
    }
}

// UI Updates
function updateUIForLoggedInFarmer() {
    // Сменяме бутона на "Моят профил"
    document.getElementById('authSection').innerHTML = 
        '<a href="#" onclick="showDashboard(); return false;">Моят профил</a>';
    
    // Показваме името
    document.getElementById('farmerName').textContent = currentFarmerData.name;
    
    // Показваме таблото, крием публичните секции
    showDashboard();

    // Скролваме нагоре
    window.scrollTo(0, 0);
}


// Guest updates
function updateUIForGuest() {
    document.getElementById('authSection').innerHTML = 
        `<a href="#" onclick="showLoginModal(); return false;">Вход</a> | <a href="#" onclick="showRegisterModal(); return false;">Регистрация</a>`;
    
    document.getElementById('farmerDashboard').style.display = 'none';
    
    const farmerPage = document.getElementById('farmerPage');
    if (farmerPage) farmerPage.style.display = 'none';
    
    const mainFilters = document.getElementById('mainFilters');
    const productsSection = document.getElementById('products');
    const farmersSection = document.getElementById('farmers');
    const aboutSection = document.getElementById('about');
    
    if (mainFilters) mainFilters.style.display = 'flex';
    if (productsSection) productsSection.style.display = 'block';
    if (farmersSection) farmersSection.style.display = 'block';
    if (aboutSection) aboutSection.style.display = 'block';
}
// Modal Functions
function showLoginModal() {
    document.getElementById('loginModal').style.display = 'flex';
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
}

function showDashboard() {
    document.getElementById('farmerDashboard').style.display = 'block';
    document.getElementById('mainFilters').style.display = 'none';
    document.getElementById('products').style.display = 'none';
    document.getElementById('farmers').style.display = 'none';
    document.getElementById('about').style.display = 'none';

    // НОВО: Зареждаме поръчките
    if (currentUser) {
        loadFarmerOrders(currentUser.uid);
    }
    window.scrollTo(0, 0);
}

function hideDashboard() {
    document.getElementById('farmerDashboard').style.display = 'none';
    document.getElementById('mainFilters').style.display = 'flex';
    document.getElementById('products').style.display = 'block';
    document.getElementById('farmers').style.display = 'block';
    document.getElementById('about').style.display = 'block';
}



async function loadFarmerOrders(farmerId) {
    const container = document.getElementById('farmerOrders');
    if (!container) {
        console.log("Няма контейнер farmerOrders");
        return;
    }
    
    container.innerHTML = '<p>Зареждане на поръчки...</p>';
    console.log("Търся поръчки за farmerId:", farmerId);
    
    try {
        // ПРОСТА ЗАЯВКА - само where, без orderBy
        const snapshot = await db.collection('orders')
            .where('farmerId', '==', farmerId)
            .get();
        
        console.log("Намерени поръчки:", snapshot.size);
        
        if (snapshot.empty) {
            container.innerHTML = '<p>Все още нямате получени поръчки.</p>';
            return;
        }
        


         container.innerHTML = '';
        
        // Събираме поръчките в масив за сортиране
        const orders = [];
        snapshot.forEach(doc => {
            orders.push({ id: doc.id, data: doc.data() });
        });
        
        // Сортираме: new най-отгоре, viewed по средата, completed най-долу
        orders.sort((a, b) => {
            const priority = { 'new': 0, 'viewed': 1, 'completed': 2 };
            const pA = priority[a.data.status] || 0;
            const pB = priority[b.data.status] || 0;
            return pA - pB;
        });
        
        // Показваме сортираните поръчки
        orders.forEach(item => {
            const order = item.data;
            const docId = item.id;
            
            console.log("Поръчка:", order);
            
            const orderDate = order.createdAt ? order.createdAt.toDate().toLocaleString('bg-BG') : 'Няма дата';
            const statusClass = order.status || 'new';
            const statusText = {
                'new': 'Нова',
                'viewed': 'Видяна',
                'completed': 'Завършена'
            }[statusClass] || 'Нова';
            
            const card = document.createElement('div');
            card.className = 'order-card ' + statusClass;
            card.innerHTML = `
                <div class="order-header">
                    <span class="order-customer">${order.customerName || 'Без име'}</span>
                    <span class="order-date">${orderDate}</span>
                </div>
                <div class="order-product">📦 Продукт: ${order.productName || 'Неизвестен продукт'}</div>
                <div class="order-phone">📞 ${order.customerPhone || 'Няма телефон'}</div>
                <div class="order-message">"${order.message || 'Без съобщение'}"</div>
                <span class="order-status status-${statusClass}">${statusText}</span>
                <div class="order-actions">
                    ${statusClass === 'new' ? `<button class="btn-small btn-view" onclick="updateOrderStatus('${docId}', 'viewed')">Маркирай като видяна</button>` : ''}
                    ${statusClass !== 'completed' ? `<button class="btn-small btn-complete" onclick="updateOrderStatus('${docId}', 'completed')">Маркирай като завършена</button>` : ''}
                </div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error("Грешка при зареждане на поръчки:", error);
        container.innerHTML = '<p style="color: red;">Грешка при зареждане: ' + error.message + '</p>';
    }
}



async function updateOrderStatus(orderId, newStatus) {
    try {
        await db.collection('orders').doc(orderId).update({
            status: newStatus
        });
        // Презареждаме поръчките
        if (currentUser) {
            loadFarmerOrders(currentUser.uid);
        }
    } catch (error) {
        console.error("Грешка:", error);
        alert("Грешка при обновяване на статуса");
    }
}



// Login
async function login(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        await auth.signInWithEmailAndPassword(email, password);
        closeLoginModal();
    } catch (error) {
        alert("Грешка при вход: " + error.message);
    }
}

// Logout
async function logout() {
    await auth.signOut();
    location.reload();
}

// Add Product
async function addProduct(e) {
    e.preventDefault();
    


    // ВАЛИДАЦИЯ - проверяваме дали полетата са празни
    const name = document.getElementById('prodName').value.trim();
    const price = document.getElementById('prodPrice').value.trim();
    const description = document.getElementById('prodDesc').value.trim();
    
    if (!name || !price || !description) {
        alert("Моля, попълнете всички полета!");
        return;
    }
    
    if (name.length < 2) {
        alert("Името на продукта трябва да е поне 2 символа!");
        return;
    }
    
    // Проверка за цена (да съдържа поне една цифра)
    if (!/\d/.test(price)) {
        alert("Моля, въведете валидна цена (напр. 6.00 лв.)!");
        return;
    }
    

    // Спира бутона временно
    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = "Запазване...";
    
    if (!currentUser || !currentFarmerData) {
        alert("Трябва да сте влезли!");
        submitBtn.disabled = false;
        submitBtn.textContent = "Добави продукт";
        return;
    }
    
    try {
        const productData = {
            name: document.getElementById('prodName').value,
            category: document.getElementById('prodCategory').value,
            price: document.getElementById('prodPrice').value,
            description: document.getElementById('prodDesc').value,
            available: document.getElementById('prodAvailable').checked, // НОВО
            farmerId: currentUser.uid,
            farmerName: currentFarmerData.name,
            location: currentFarmerData.location,
            coords: currentFarmerData.coords,
            createdAt: new Date(),
            emoji: getEmojiForCategory(document.getElementById('prodCategory').value)
        };
        
        // Запазваме в базата
        await db.collection('products').add(productData);
        
        // Изчистваме формата
        document.getElementById('productForm').reset();
        
        alert("Продуктът е добавен успешно!");
        
        // Презареждаме списъка (това работеше преди)
        await loadMyProducts(currentUser.uid);
        loadAllProducts();
        
    } catch (error) {
        console.error("Грешка:", error);
        alert("Грешка при добавяне: " + error.message);
    } finally {
        // Връщаме бутона
        submitBtn.disabled = false;
        submitBtn.textContent = "Добави продукт";
    }
}


function getEmojiForCategory(cat) {
    if (!cat) return '📦';
    const c = cat.toLowerCase().trim();
    
    // Яйца
    if (c.includes('яйца') || c.includes('egg')) return '🥚';
    
    // Месо
    if (c.includes('месо') || c.includes('пиле') || c.includes('теле') || c.includes('свин') || c.includes('агне') || c.includes('meat') || c.includes('chicken') || c.includes('beef') || c.includes('pork')) return '🥩';
    
    // Мед
    if (c.includes('мед') || c.includes('honey')) return '🍯';
    
    // Млечни
    if (c.includes('сирене') || c.includes('кашкавал') || c.includes('мляко') || c.includes('кисело') || c.includes('йогурт') || c.includes('cheese') || c.includes('milk')) return '🧀';
    
    // Зеленчуци
    if (c.includes('зеленчук') || c.includes('домат') || c.includes('краставица') || c.includes('чушка') || c.includes('лук') || c.includes('чесън') || c.includes('tikv') || c.includes('vegetable') || c.includes('tomato') || c.includes('pepper')) return '🥒';
    
    // Плодове
    if (c.includes('плод') || c.includes('ябълк') || c.includes('круш') || c.includes('слив') || c.includes('прасков') || c.includes('череш') || c.includes('fruit') || c.includes('apple') || c.includes('pear')) return '🍎';
    
    // Хляб
    if (c.includes('хляб') || c.includes('питка') || c.includes('баница') || c.includes('bread')) return '🍞';
    
    // Билки/подправки
    if (c.includes('билк') || c.includes('чай') || c.includes('подправк') || c.includes('herb') || c.includes('tea') || c.includes('spice')) return '🌿';
    
    // Вино/алкохол
    if (c.includes('вино') || c.includes('ракия') || c.includes('бира') || c.includes('wine') || c.includes('beer')) return '🍷';
    
    // Ядки
    if (c.includes('ядк') || c.includes('орех') || c.includes('лешник') || c.includes('бадем') || c.includes('nuts') || c.includes('walnut')) return '🥜';
    
    // Цветя/растения
    if (c.includes('цвет') || c.includes('роз') || c.includes('растен') || c.includes('flower') || c.includes('plant')) return '🌸';
    
    // По подразбиране
    return '📦';
}


// Load My Products (for dashboard)
async function loadMyProducts(farmerId) {
    const container = document.getElementById('myProducts');
    container.innerHTML = 'Зареждане...';
    
    try {
        const snapshot = await db.collection('products')
            .where('farmerId', '==', farmerId)
            .get();
        
        if (snapshot.empty) {
            container.innerHTML = '<p>Все още нямате добавени продукти.</p>';
            return;
        }
        
        container.innerHTML = '';
        snapshot.forEach(doc => {
            const product = doc.data();
            const card = createProductCard(doc.id, product, true);
            container.appendChild(card);
        });
    } catch (error) {
        console.error("Error loading products:", error);
    }
}

// Load All Products (for public view)
async function loadAllProducts() {
    const grid = document.getElementById('productsGrid');
    grid.innerHTML = 'Зареждане...';
    
    try {
        const snapshot = await db.collection('products').get();
        window.allProducts = []; // Store for filtering
        
        snapshot.forEach(doc => {
            window.allProducts.push({ id: doc.id, ...doc.data() });
        });
        
        renderProducts(window.allProducts);
    } catch (error) {
        console.error("Error loading products:", error);
    }
}

// Load Farmers
async function loadFarmers() {
    const grid = document.getElementById('farmersGrid');
    
    try {
        const snapshot = await db.collection('farmers').get();
        grid.innerHTML = '';
        
        snapshot.forEach(doc => {
            const farmer = doc.data();
            const card = document.createElement('div');
            card.className = 'farmer-card';
            card.style.cursor = 'pointer';
            card.onclick = () => openGoogleMaps(farmer.coords, null, farmer.name);
            
            const specialties = farmer.specialties.map(s => 
                s === 'eggs' ? '🥚' : s === 'meat' ? '🥩' : '🍯'
            ).join(' ');
            
            const specialtyNames = farmer.specialties.map(s => 
                s === 'eggs' ? 'яйца' : s === 'meat' ? 'месо' : 'мед'
            ).join(', ');
            
            card.innerHTML = `
                <div class="farmer-avatar">👨‍🌾</div>
                <h3 class="farmer-name">${farmer.owner}</h3>
                <p style="color: #888; font-size: 0.9rem;">📍 ${farmer.name}</p>
                <button class="contact-btn" style="margin-top: 1rem; width: 100%;" onclick="event.stopPropagation(); showFarmerContact('${doc.id}')">📞 Свържи се с фермера</button>

            `;
            grid.appendChild(card);
        });
    } catch (error) {
        console.error("Error loading farmers:", error);
    }
}

// Create Product Card
function createProductCard(id, product, isOwner = false) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    if (!isOwner) {
        card.style.cursor = 'pointer';
            card.onclick = (e) => {
                if (!e.target.closest('.product-actions')) {
                    // GeoPoint формат: предаваме целия обект
                    openGoogleMaps(product.coords, null, product.farmerName);
                }
            };
        }
    

    let orderBtnHtml = '';
        if (!isOwner && !currentUser) {
            if (product.available !== false) {
                orderBtnHtml = `<button class="contact-btn" onclick="event.stopPropagation(); showOrderModal('${id}', '${product.name}', '${product.farmerName}', '${product.farmerId}')">Направи поръчка</button>`;
            } else {
                orderBtnHtml = `<button class="contact-btn" style="background: #999; cursor: not-allowed;" disabled>Изчерпано</button>`;
            }
        }   



    let actionsHtml = '';
    if (isOwner) {
        actionsHtml = `
            <div class="product-actions">
                <button class="edit-btn" onclick="showEditModal('${id}')">Редактирай</button>
                <button class="delete-btn" onclick="deleteProduct('${id}')">Изтрий</button>
            </div>
        `;
    }

    const availabilityBadge = product.available !== false 
        ? '<span class="available-badge">✅ В наличност</span>' 
        : '<span class="unavailable-badge">❌ Изчерпано</span>';

    card.innerHTML = `
        <div class="product-image">${product.emoji}</div>
        <div class="product-info">

            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.5rem;">
                <span class="product-category">${getCategoryName(product.category)}</span>
                ${availabilityBadge}
            </div>

            <h3 class="product-name">${product.name}</h3>
            <p class="product-farmer">от ${product.farmerName}</p>
            <div class="product-location">📍 ${product.location}</div>
            <p style="color: #2d5016; font-size: 0.8rem; margin-top: 0.3rem; font-weight: 500;">🗺️ Кликни за място на картата</p><br>
            <p style="color: #666; font-size: 0.9rem; margin-bottom: 0.5rem;">${product.description}</p>
            <div class="product-price">${product.price}</div>
            ${orderBtnHtml}
            ${actionsHtml}
        </div>
    `;
    
    return card;
}


function getCategoryName(category) {
    const names = { 'eggs': 'яйца', 'meat': 'месо', 'honey': 'мед' };
    return names[category] || category;
}

// Delete Product
async function deleteProduct(productId) {
    if (!confirm('Сигурни ли сте, че искате да изтриете този продукт?')) return;
    
    try {
        await db.collection('products').doc(productId).delete();
        loadMyProducts(currentUser.uid);
        loadAllProducts();
    } catch (error) {
        console.error("Error deleting:", error);
    }
}

// Показва прозореца за редакция и зарежда данните
async function showEditModal(productId) {
    try {
        // Взимаме продукта от базата
        const doc = await db.collection('products').doc(productId).get();
        const product = doc.data();
        
        // Попълваме формата с текущите стойности
        document.getElementById('editProductId').value = productId;
        document.getElementById('editName').value = product.name;
        document.getElementById('editCategory').value = product.category;
        document.getElementById('editPrice').value = product.price;
        document.getElementById('editDescription').value = product.description;
        document.getElementById('editAvailable').checked = product.available !== false;
        
        // Показваме прозореца
        document.getElementById('editModal').style.display = 'flex';
    } catch (error) {
        console.error("Грешка при зареждане:", error);
        alert("Не може да се зареди продуктът");
    }
}

// Затваря прозореца
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function showRegisterModal() {
    document.getElementById('registerModal').style.display = 'flex';
}

function closeRegisterModal() {
    document.getElementById('registerModal').style.display = 'none';
}





async function registerFarmer(e) {
    e.preventDefault();
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = "Създаване...";
    
    // Взимаме стойностите
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const farmName = document.getElementById('regFarmName').value.trim();
    const owner = document.getElementById('regOwner').value.trim();
    const location = document.getElementById('regLocation').value.trim();
    const lat = parseFloat(document.getElementById('regLat').value);
    const lng = parseFloat(document.getElementById('regLng').value);
    
    // Специалности
    const specialties = []; // Празен масив за сега, може да се добавят после
    
    // Валидация
    if (!email || !password || !farmName || !owner || !location || isNaN(lat) || isNaN(lng)) {
        alert("Моля, попълнете всички полета правилно!");
        submitBtn.disabled = false;
        submitBtn.textContent = "Създай профил";
        return;
    }
    
    if (password.length < 6) {
        alert("Паролата трябва да е поне 6 символа!");
        submitBtn.disabled = false;
        submitBtn.textContent = "Създай профил";
        return;
    }
    
    
    try {
        // Създаваме потребител в Authentication
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const uid = userCredential.user.uid;
        
        // Запазваме данните за фермера в Firestore
        await db.collection('farmers').doc(uid).set({
            name: farmName,
            owner: owner,
            location: location,
            phone: document.getElementById('regPhone').value.trim(),
            coords: new firebase.firestore.GeoPoint(lat, lng),
            specialties: [],
            email: email
        });
        
        alert("Регистрацията е успешна! Вече можете да влезете.");
        document.getElementById('registerForm').reset();
        closeRegisterModal();
        
    } catch (error) {
        console.error("Грешка при регистрация:", error);
        let msg = "Грешка при регистрация: ";
        if (error.code === 'auth/email-already-in-use') {
            msg += "Този имейл вече се използва.";
        } else if (error.code === 'auth/invalid-email') {
            msg += "Невалиден имейл.";
        } else {
            msg += error.message;
        }
        alert(msg);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = "Създай профил";
    }
}


async function showFarmerContact(farmerId) {
    try {
        const doc = await db.collection('farmers').doc(farmerId).get();
        if (!doc.exists) {
            alert('Фермерът не е намерен');
            return;
        }
        const farmer = doc.data();
        
        document.getElementById('contactFarmName').textContent = farmer.name || 'Без име';
        document.getElementById('contactOwner').textContent = farmer.owner || '';
        document.getElementById('contactEmail').textContent = farmer.email || 'Няма имейл';
        document.getElementById('contactPhone').textContent = farmer.phone || 'Не е посочен';
        document.getElementById('contactLocation').textContent = farmer.location || '';
        
        document.getElementById('farmerContactModal').style.display = 'flex';
    } catch (error) {
        console.error('Грешка при зареждане на контакти:', error);
        alert('Грешка при зареждане на контактите');
    }
}

function closeFarmerContact() {
    document.getElementById('farmerContactModal').style.display = 'none';
}


function showOrderModal(productId, productName, farmerName, farmerId) {
    document.getElementById('orderProductId').value = productId;
    document.getElementById('orderFarmerId').value = farmerId;
    document.getElementById('orderProductName').value = productName; // НОВО
    document.getElementById('orderProductInfo').textContent = 
        'Продукт: ' + productName + ' от ' + farmerName;
    document.getElementById('orderModal').style.display = 'flex';
}

function closeOrderModal() {
    document.getElementById('orderModal').style.display = 'none';
}

async function submitOrder(e) {
    e.preventDefault();
    
    const customerName = document.getElementById('orderName').value.trim();
    const customerPhone = document.getElementById('orderPhone').value.trim();
    const message = document.getElementById('orderMessage').value.trim();
    
    if (!customerName || !customerPhone || !message) {
        alert("Моля, попълнете всички полета!");
        return;
    }
    
    const orderData = {
        productId: document.getElementById('orderProductId').value,
        farmerId: document.getElementById('orderFarmerId').value,
        productName: document.getElementById('orderProductName').value, // СМЕНЕНО
        customerName: customerName,
        customerPhone: customerPhone,
        message: message,
        status: 'new',
        createdAt: new Date()
    };
    
    try {
        await db.collection('orders').add(orderData);
        alert("Запитването е изпратено успешно! Фермерът ще се свърже с вас.");
        document.getElementById('orderForm').reset();
        closeOrderModal();
    } catch (error) {
        console.error("Грешка при поръчка:", error);
        alert("Грешка при изпращане. Опитайте отново.");
    }
}


// Запазва промените в базата
async function saveEdit(e) {
    e.preventDefault();
    
    const productId = document.getElementById('editProductId').value;
    const updatedData = {
        name: document.getElementById('editName').value,
        category: document.getElementById('editCategory').value,
        price: document.getElementById('editPrice').value,
        description: document.getElementById('editDescription').value,
        available: document.getElementById('editAvailable').checked,
        emoji: getEmojiForCategory(document.getElementById('editCategory').value)
    };
    
    try {
        await db.collection('products').doc(productId).update(updatedData);
        closeEditModal();
        closeEditModal();
        alert("Продуктът е обновен!");
        await loadMyProducts(currentUser.uid);
        await loadAllProducts(); // НОВО: Презареждаме и публичните продукти
    } catch (error) {
        console.error("Грешка при запис:", error);
        alert("Грешка при запазване на промените");
    }
}



// Filter Functions
function renderProducts(productsToRender) {
    const grid = document.getElementById('productsGrid');
    grid.innerHTML = '';
    
    productsToRender.forEach(product => {
        const card = createProductCard(product.id, product, false);
        grid.appendChild(card);
    });
}


function filterCategory(category) {
    // Активен бутон
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    if (category === 'all') {
        renderProducts(window.allProducts);
        return;
    }
    
    // Ключови думи за всяка категория
    const keywords = {
        'eggs': ['яйца', 'egg'],
        'meat': ['месо', 'пиле', 'теле', 'свин', 'агне', 'meat', 'chicken', 'beef', 'pork', 'кайма'],
        'honey': ['мед', 'honey', 'пчелен', 'восък'],
        'dairy': ['сирене', 'кашкавал', 'мляко', 'кисело', 'йогурт', 'извара', 'масло', 'cheese', 'milk', 'butter', 'yogurt'],
        'vegetables': ['зеленчук', 'домат', 'краставица', 'чушка', 'лук', 'чесън', 'тикв', 'морков', 'зеле', 'спанак', 'vegetable', 'tomato', 'pepper', 'cucumber', 'onion', 'garlic', 'carrot', 'cabbage'],
        'fruits': ['плод', 'ябълк', 'круш', 'слив', 'прасков', 'череш', 'ягод', 'малин', 'кайси', 'грозд', 'fruit', 'apple', 'pear', 'plum', 'peach', 'cherry', 'strawberry', 'raspberry', 'grape'],
        'bread': ['хляб', 'питка', 'баница', 'тутманик', 'мекич', 'погача', 'bread', 'pastry'],
        'other': [] // Ще обработим отделно
    };
    
    if (category === 'other') {
        // "Други" = всичко, което НЕ е в горните категории
        const allKeywords = Object.values(keywords).flat();
        const filtered = window.allProducts.filter(product => {
            const prodCat = (product.category || '').toLowerCase();
            return !allKeywords.some(word => prodCat.includes(word));
        });
        renderProducts(filtered);
        return;
    }
    
    const searchWords = keywords[category] || [category];
    
    const filtered = window.allProducts.filter(product => {
        const prodCat = (product.category || '').toLowerCase();
        return searchWords.some(word => prodCat.includes(word));
    });
    
    renderProducts(filtered);
}


function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    const filtered = window.allProducts.filter(product => 
        product.name.toLowerCase().includes(searchTerm) ||
        product.farmerName.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm)
    );
    renderProducts(filtered);
}

document.getElementById('searchInput')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') filterProducts();
});

// Google Maps
function openGoogleMaps(lat, lng, label) {
    console.log("Получени координати:", lat, lng);
    
    // Ако е GeoPoint обект (от базата), ползваме .latitude/.longitude
    // Ако са отделни параметри, ги ползваме директно
    let latitude, longitude;
    
    if (typeof lat === 'object' && lat !== null) {
        // Формат: {latitude: 42.6977, longitude: 23.3219} (GeoPoint)
        latitude = lat.latitude;
        longitude = lat.longitude;
    } else {
        // Формат: отделни числа или стрингове
        latitude = Number(lat);
        longitude = Number(lng);
    }
    
    // Ако lng е undefined, но lat има и двете стойности (случай с обект)
    if (lng === undefined && typeof lat === 'object') {
        longitude = lat.longitude;
    }
    
    console.log("Конвертирани:", latitude, longitude);
    
    if (!latitude || !longitude || isNaN(latitude) || isNaN(longitude)) {
        alert('Невалидни координати за това местоположение');
        return;
    }
    
    const mapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}&ll=${latitude},${longitude}&z=15`;
    window.open(mapsUrl, '_blank');
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadAllProducts();
    loadFarmers();
});